/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   7-4-1-2-1_execute_shared_rotations.c              :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:52 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:52 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// AとBが同じ方向へ回る部分をrrまたはrrrで同時に実行する

void	execute_shared_rotations(t_program *program, t_move *move)
{
	while (move->a_steps > 0 && move->b_steps > 0
			&& move->a_reverse == move->b_reverse)
	{
		if (move->a_reverse)
			op_rrr(program);
		else
			op_rr(program);
		move->a_steps--;
		move->b_steps--;
	}
}
