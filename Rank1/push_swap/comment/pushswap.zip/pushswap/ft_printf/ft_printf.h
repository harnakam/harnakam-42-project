/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.h                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: harnakam <harnakam@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/05/18 21:20:00 by harnakam          #+#    #+#             */
/*   Updated: 2026/05/18 21:20:00 by harnakam         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#ifndef FT_PRINTF_H
# define FT_PRINTF_H

# include <stdarg.h>
# include <unistd.h>

int	ft_printf(const char *format, ...);
int	ft_pf_putchar(char c);
int	ft_pf_putstr(char *s);
int	ft_pf_putnbr(int n);
int	ft_pf_putunsigned(unsigned int n);
int	ft_pf_puthex(unsigned int n, char upper);
int	ft_pf_putptr(void *ptr);

#endif
