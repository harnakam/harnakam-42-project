#include "push_swap.h"

// 一時配列の指定範囲を元の配列へコピーする
void	copy_merged_values(int *values, const int *temporary,
	size_t left, size_t right)
{
	while (left < right)
	{
		values[left] = temporary[left];
		left++;
	}
}
