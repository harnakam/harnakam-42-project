/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   utils-13_op_sa.c                                  :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:48:45 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:48:58 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// スタックAの先頭二要素を交換し、saを出力する

void	op_sa(t_program *program)
{
	if (program->size_a < 2)
		return ;
	swap_stack(program->stack_a);
	print_operation(program, "sa", &program->operations.sa);
}
