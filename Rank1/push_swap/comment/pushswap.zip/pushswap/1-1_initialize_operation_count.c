/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   1-1_initialize_operation_count.c                  :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:07 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:07 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// すべての命令別カウンタと合計カウンタを0に初期化する

void	initialize_operation_count(t_operation_count *operations)
{
	ft_bzero(operations, sizeof(*operations));
}
