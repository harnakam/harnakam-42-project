/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   utils-10_push_stack.c                             :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:48:41 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:50:21 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 移動元の先頭ノードを取り外し、移動先の先頭へ追加する
void push_stack(t_node * *source, t_node * *destination,
	size_t	*source_size, size_t *destination_size)
{
	t_node	*node;

	if (*source == NULL)
		return ;
	node = *source;
	*source = node->next;
	if (*source != NULL)
		(*source)->prev = NULL;
	node->prev = NULL;
	node->next = *destination;
	if (*destination != NULL)
		(*destination)->prev = node;
	*destination = node;
	(*source_size)--;
	(*destination_size)++;
}
