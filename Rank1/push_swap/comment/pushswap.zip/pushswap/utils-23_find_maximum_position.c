/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   utils-23_find_maximum_position.c                  :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:48:50 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:48:50 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// スタック内で順位が最大のノードが先頭から何番目か調べる

size_t	find_maximum_position(t_node *stack)
{
	t_node	*node;
	size_t	position;
	size_t	best_position;

	node = stack;
	position = 0;
	best_position = 0;
	while (node != NULL)
	{
		if (node->index > stack->index)
		{
			stack = node;
			best_position = position;
		}
		node = node->next;
		position++;
	}
	return (best_position);
}
