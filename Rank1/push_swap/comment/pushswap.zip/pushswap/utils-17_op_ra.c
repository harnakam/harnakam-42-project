#include "push_swap.h"

// スタックAを上方向へ一つ回転し、raを出力する
void	op_ra(t_program *program)
{
	if (program->size_a < 2)
		return ;
	rotate_stack(&program->stack_a);
	print_operation(program, "ra", &program->operations.ra);
}
