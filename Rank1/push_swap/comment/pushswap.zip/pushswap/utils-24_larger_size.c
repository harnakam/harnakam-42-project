/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   utils-24_larger_size.c                            :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:48:48 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:48:48 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 二つのsize_t型の値を比較し、大きい方を返す

size_t	larger_size(size_t first, size_t second)
{
	if (first > second)
		return (first);
	return (second);
}
