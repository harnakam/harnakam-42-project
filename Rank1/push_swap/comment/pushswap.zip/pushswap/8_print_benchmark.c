/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   8_print_benchmark.c                               :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/22 22:19:03 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:55 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// ベンチマークが有効な場合だけ、ソート結果の情報を標準エラーへ表示する

void	print_benchmark_if_enabled(const t_program *program)
{
	// 8-1. --benchが指定されているか確認する
	if (!program->bench_enabled)
		return ;
	// 8-2. ベンチマークの見出しと乱れ具合を表示する
	ft_putendl_fd("=== push_swap benchmark ===", 2);
	print_disorder(program->initial_disorder);
	// 8-3. 使用した方法と計算量を表示する
	ft_putstr_fd("Strategy: ", 2);
	ft_putendl_fd((char *) get_strategy_name(program->selected_strategy), 2);
	ft_putstr_fd("Complexity: ", 2);
	ft_putendl_fd((char *) get_strategy_complexity(
			program->selected_strategy), 2);
	// 8-4. 命令ごとの操作回数を表示する
	print_operation_counts(&program->operations);
}
