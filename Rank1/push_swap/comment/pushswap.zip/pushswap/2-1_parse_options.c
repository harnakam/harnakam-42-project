/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   2-1_parse_options.c                               :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/22 17:34:46 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:10 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// すべての引数からソート方法とベンチマーク指定を読み取る
// 不正な指定は1、正しい指定は0を返す

int	parse_options(t_program *program)
{
	int	i;

	// 2-1-1. すべてのオプション引数を順番に処理する
	i = 1;
	while (i < program->argc)
	{
		if (is_option(program->argv[i]))
			if (parse_one_option(program, program->argv[i]) == ERROR)
				return (ERROR);
		i++;
	}
	// 2-1-2. 方法が未指定ならadaptiveを使用する
	if (program->requested_strategy == STRATEGY_NONE)
		program->requested_strategy = STRATEGY_ADAPTIVE;
	return (SUCCESS);
}
