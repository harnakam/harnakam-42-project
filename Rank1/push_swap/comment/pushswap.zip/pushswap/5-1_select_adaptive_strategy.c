/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   5-1_select_adaptive_strategy.c                    :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:22 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:22 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 要素数と最初の乱れ具合から適したソート方法を選ぶ

t_strategy	select_adaptive_strategy(const t_program *program)
{
	if (program->size_a <= 5)
		return (STRATEGY_SIMPLE);
	if (program->initial_disorder < 0.20)
		return (STRATEGY_SIMPLE);
	if (program->initial_disorder < 0.50)
		return (STRATEGY_MEDIUM);
	return (STRATEGY_COMPLEX);
}
