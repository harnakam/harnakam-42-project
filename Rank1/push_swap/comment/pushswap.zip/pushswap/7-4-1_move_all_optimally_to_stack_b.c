/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   7-4-1_move_all_optimally_to_stack_b.c             :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:42 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:43 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 各時点で最も少ない操作数で移せる要素をスタックBへ移動する

void	move_all_optimally_to_stack_b(t_program *program)
{
	t_move	move;

	while (program->size_a > 0)
	{
		move = choose_move(program);
		execute_move(program, move);
	}
}
