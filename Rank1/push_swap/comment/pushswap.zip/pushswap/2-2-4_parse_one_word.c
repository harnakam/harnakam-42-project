/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   2-2-4_parse_one_word.c                            :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:17 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:17 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 空白を含まない一単語を検証し、整数としてスタックAへ追加する

int	parse_one_word(t_program *program, const char *start, size_t length)
{
	int	value;

	if (parse_integer(start, length, &value) == ERROR)
		return (ERROR);
	if (value_already_exists(program, value))
		return (ERROR);
	if (append_value_to_stack_a(program, value) == ERROR)
		return (ERROR);
	return (SUCCESS);
}
