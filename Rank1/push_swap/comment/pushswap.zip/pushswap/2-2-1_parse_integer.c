/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   2-2-1_parse_integer.c                             :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:13 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:13 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 指定された長さの文字列をint型の整数へ変換する
// 形式や範囲が不正な場合は1を返す

int	parse_integer(const char *string, size_t length, int *result)
{
	long	number;
	int		sign;
	size_t	i;

	if (length == 0)
		return (ERROR);
	i = 0;
	// 2-2-1-1. 先頭の符号を読み取る
	sign = read_integer_sign(string, &i);
	if (i == length)
		return (ERROR);
	// 2-2-1-2. 残りの数字を検証しながら整数へ変換する
	if (read_integer_digits(string, length, i, sign, &number) == ERROR)
		return (ERROR);
	*result = (int)(number * sign);
	return (SUCCESS);
}
