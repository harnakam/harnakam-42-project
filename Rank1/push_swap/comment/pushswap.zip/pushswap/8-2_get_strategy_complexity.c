/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   8-2_get_strategy_complexity.c                     :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:57 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:57 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// ソート方法をベンチマーク表示用の計算量へ変換する

const char	*get_strategy_complexity(t_strategy strategy)
{
	if (strategy == STRATEGY_SIMPLE)
		return ("O(n^2)");
	if (strategy == STRATEGY_MEDIUM)
		return ("O(n sqrt(n))");
	if (strategy == STRATEGY_COMPLEX)
		return ("O(n log(n))");
	if (strategy == STRATEGY_ULTRA)
		return ("operation optimized");
	return ("unknown");
}
