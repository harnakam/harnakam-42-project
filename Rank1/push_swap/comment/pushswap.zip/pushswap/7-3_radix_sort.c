/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   7-3_radix_sort.c                                  :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:39 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:39 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 要素の順位をbitごとにBへ振り分け、下位bitから昇順に並べる

void	radix_sort(t_program *program)
{
	size_t	bit;
	size_t	bits;

	// 7-3-1. 各要素へ値の順位を割り当てる
	if (assign_rank_indexes(program) == ERROR)
		return ;
	// 7-3-2. 最大順位を表現するために必要なbit数を求める
	bits = count_rank_bits(program->size_a);
	bit = 0;
	// 7-3-3. 下位bitから順番に要素を振り分ける
	while (bit < bits && !stack_a_is_sorted(program))
		radix_pass(program, bit++);
}
