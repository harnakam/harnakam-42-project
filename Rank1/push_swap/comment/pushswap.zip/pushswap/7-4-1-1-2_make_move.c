/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   7-4-1-1-2_make_move.c                             :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:50 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:50 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// AとBの回転方向から、指定要素を移動する手順と操作数を作る
t_move make_move(t_program * program, size_t a_position,
	size_t	b_position, int mode)
{
	t_move	move;

	move.a_reverse = (mode == 1 || mode == 3);
	move.b_reverse = (mode == 1 || mode == 2);
	move.a_steps = a_position;
	move.b_steps = b_position;
	if (move.a_reverse && a_position != 0)
		move.a_steps = program->size_a - a_position;
	if (move.b_reverse && b_position != 0)
		move.b_steps = program->size_b - b_position;
	if (move.a_reverse == move.b_reverse)
		move.cost = larger_size(move.a_steps, move.b_steps);
	else
		move.cost = move.a_steps + move.b_steps;
	return (move);
}
