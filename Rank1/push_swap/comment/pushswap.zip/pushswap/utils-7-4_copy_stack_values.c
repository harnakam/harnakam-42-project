#include "push_swap.h"

// スタックの値を先頭から順番に整数配列へコピーする
void	copy_stack_values(t_node *stack, int *values)
{
	size_t	position;

	position = 0;
	while (stack != NULL)
	{
		values[position++] = stack->value;
		stack = stack->next;
	}
}
