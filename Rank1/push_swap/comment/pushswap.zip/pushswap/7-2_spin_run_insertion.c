/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   7-2_spin_run_insertion.c                          :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:30 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:30 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

/* ************************************************************************** */

#include "push_swap.h"

// 順位の近い要素をrunとしてまとめ、最大要素からAへ挿入する

void	spin_run_insertion(t_program *program)
{
	size_t	width;

	// 7-2-1. 各要素へ値の順位を割り当てる
	if (assign_rank_indexes(program) == ERROR)
		return ;
	// 7-2-2. 要素数からrunの幅を求める
	width = chunk_width(program->size_a);
	// 7-2-3. 順位が近い要素をrunとしてBへまとめる
	move_runs_to_stack_b(program, width);
	// 7-2-4. 大きい要素からAへ戻して昇順を完成させる
	restore_runs_to_stack_a(program);
}
