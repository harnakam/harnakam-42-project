# push_swap

## 目次

- [概要](#概要)
- [特徴](#特徴)
- [使用できる命令](#使用できる命令)
- [ビルド](#ビルド)
- [使い方](#使い方)
- [ソート戦略](#ソート戦略)
- [ベンチマーク表示](#ベンチマーク表示)
- [Bonus: checker](#bonus-checker)
- [ファイル構成](#ファイル構成)
- [コメント付きソースのバックアップ](#コメント付きソースのバックアップ)
- [クリーンアップ](#クリーンアップ)
- [参考資料](#参考資料)

[English version](README_EN.md)

## 概要

このプロジェクトは、42カリキュラムの課題として作成した`push_swap`です。
2つのスタックA・Bと限られた命令だけを使い、整数列をできるだけ少ない
操作回数で昇順に並べます。

`push_swap`は整数列を受け取り、整列に必要な命令を1行ずつ標準出力へ
表示します。整数以外、`int`の範囲外、重複した整数などの不正な入力では、
標準エラー出力へ`Error`を表示します。

## 特徴

- 入力の要素数と乱れ具合に応じたソート戦略の自動選択
- 4種類のソート戦略をコマンドラインから明示的に指定可能
- 操作回数、使用戦略、計算量、初期disorderを確認できるベンチマーク表示
- Bonusの`checker`による命令列の検証
- コメントなしの提出用ソースと、コメント付き学習用ソースを分離

## 使用できる命令

| 命令 | 動作 |
|---|---|
| `sa` / `sb` | スタックA / Bの先頭2要素を交換する |
| `ss` | `sa`と`sb`を同時に実行する |
| `pa` | スタックBの先頭要素をスタックAへ移す |
| `pb` | スタックAの先頭要素をスタックBへ移す |
| `ra` / `rb` | スタックA / Bを上方向へ1つ回転する |
| `rr` | `ra`と`rb`を同時に実行する |
| `rra` / `rrb` | スタックA / Bを下方向へ1つ回転する |
| `rrr` | `rra`と`rrb`を同時に実行する |

## ビルド

Mandatoryの`push_swap`をビルドします。

```sh
make
```

Bonusの`checker`をビルドします。

```sh
make bonus
```

コンパイルには`cc`と`-Wall -Wextra -Werror`を使用します。

## 使い方

整数を引数として渡します。先頭の整数がスタックAの先頭要素です。

```sh
./push_swap 2 1 3 6 5 8
```

複数の整数を1つの文字列として渡すこともできます。

```sh
./push_swap "2 1 3 6 5 8"
```

引数がない場合は何も表示せず終了します。不正な入力では`Error`を標準
エラー出力へ表示します。

```sh
./push_swap 0 one 2 3
./push_swap 1 2 2 3
./push_swap 2147483648
```

## ソート戦略

オプションを指定しない場合は`--adaptive`が使用されます。

| オプション | 戦略 | 概要 | 計算量の目安 |
|---|---|---|---|
| `--simple` | Spin Bubble Sort | 少数または低disorder向け | `O(n²)` |
| `--medium` | Spin Run Insertion | chunk / run単位で移動 | `O(n√n)` |
| `--complex` | Radix Sort | 大規模または高disorder向け | `O(n log n)` |
| `--ultra` | OptiCSRI | 各要素の挿入コストを比較して操作数を抑える | 操作数最適化 |
| `--adaptive` | Adaptive | 要素数と初期disorderから戦略を自動選択 | 選択した戦略による |

Adaptiveは、要素数が5以下またはdisorderが20%未満ならSimple、50%未満
ならMedium、それ以外ではComplexを選択します。

```sh
./push_swap --simple 3 2 1
./push_swap --medium 8 3 7 1 6 2 5 4
./push_swap --complex 9 1 8 2 7 3 6 4 5
./push_swap --ultra 5 2 8 1 7 3 6 4
```

## ベンチマーク表示

`--bench`を付けると、初期disorder、選択された戦略、計算量、命令ごとの
操作回数を標準エラー出力へ表示します。ソート命令は通常どおり標準出力へ
出るため、`checker`へのパイプを妨げません。

```sh
./push_swap --bench --adaptive 4 67 3 87 23
```

## Bonus: checker

`checker`はスタックAを引数として受け取り、標準入力から命令列を読みます。
すべての命令を実行したあと、スタックAが昇順でスタックBが空なら`OK`、
それ以外なら`KO`を標準出力へ表示します。不正な引数や存在しない命令では、
`Error`を標準エラー出力へ表示します。

`push_swap`が出力した命令列を検証する例:

```sh
ARG="4 67 3 87 23"
./push_swap $ARG | ./checker $ARG
```

操作回数を数える例:

```sh
ARG="4 67 3 87 23"
./push_swap $ARG | wc -l
```

手動で命令を渡すこともできます。

```sh
printf 'sa\nrra\n' | ./checker 3 2 1
```

## ファイル構成

ルート直下のソースは処理順を追いやすいように番号を付けています。

```text
N_工程本体.c
└── N-M_工程の種類・部品.c
    └── N-M-P_さらに細かい部品.c
```

主な構成:

```text
.
├── push_swap.c / push_swap.h       Mandatory本体
├── [番号付きソース].c             入力処理・戦略選択・ソート・表示
├── utils-*.c                       スタック操作と共通処理
├── Libft/                          自作Libft
├── ft_printf/                      自作ft_printf
├── commented/                      コメント付きMarkdown版
└── commented-source-backup.tar.gz  コメント付きCソースのバックアップ
```

Bonusを提出する場合、`checker`用のソースは課題要件に従って`*_bonus.c` /
`*_bonus.h`として分離し、Makefileの`bonus`ルールからビルドします。

## コメント付きソースのバックアップ

提出・Norminette用の`.c` / `.h`からは説明コメントを除いています。コメント
付きコードは次の2形式で保存しています。

- `commented/*.md`: Cのシンタックスハイライト付きで閲覧するMarkdown版
- `commented-source-backup.tar.gz`: 実際の`.c` / `.h`を含むバックアップ

アーカイブの内容だけを確認します。

```sh
tar -tzf commented-source-backup.tar.gz
```

バックアップ内の`.c` / `.h`をNorminetteの対象にしないため、リポジトリ外の
`/tmp`へ展開する方法を推奨します。

```sh
mkdir -p /tmp/push_swap-commented
tar -xzf commented-source-backup.tar.gz -C /tmp/push_swap-commented
```

展開先は次の場所です。

```text
/tmp/push_swap-commented/commented-source-backup/
```

確認後に削除する場合:

```sh
rm -r /tmp/push_swap-commented
```

リポジトリ内へ展開すると、コメント付き`.c` / `.h`もNorminetteの検索対象に
なる可能性があります。提出前はアーカイブのまま保持してください。

## クリーンアップ

```sh
make clean   # オブジェクトファイルを削除
make fclean  # オブジェクトファイルと実行ファイルを削除
make re      # すべて削除して再ビルド
```

## 参考資料

- [Push_swap subject](Push_swap.pdf)
- [English README](README_EN.md)

