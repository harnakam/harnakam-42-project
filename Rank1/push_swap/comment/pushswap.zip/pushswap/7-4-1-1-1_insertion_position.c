/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   7-4-1-1-1_insertion_position.c                    :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:48 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:48 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 指定された順位をスタックBの降順循環列へ挿入する位置を求める

size_t	insertion_position(t_program *program, int index)
{
	t_node	*node;
	t_node	*previous;
	size_t	position;
	size_t	maximum;

	if (program->size_b < 2)
		return (0);
	maximum = find_maximum_position(program->stack_b);
	node = program->stack_b;
	previous = node;
	while (previous->next != NULL)
		previous = previous->next;
	position = 0;
	while (node != NULL)
	{
		if (previous->index > index && index > node->index)
			return (position);
		previous = node;
		node = node->next;
		position++;
	}
	return (maximum);
}
