/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   7-4-1-1_choose_move.c                             :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:46 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:46 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// すべての候補を比較し、必要な操作数が最小の移動を選ぶ

t_move	choose_move(t_program *program)
{
	t_move	best;
	t_node	*node;
	size_t	a_position;

	best.cost = (size_t) - 1;
	node = program->stack_a;
	a_position = 0;
	while (node != NULL)
	{
		best = choose_node_move(program, node, a_position, best);
		node = node->next;
		a_position++;
	}
	return (best);
}
