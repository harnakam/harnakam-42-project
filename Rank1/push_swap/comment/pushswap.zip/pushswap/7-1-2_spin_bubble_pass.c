/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   7-1-2_spin_bubble_pass.c                          :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:29 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:29 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// スタックAを一周し、循環境界以外の逆順になった隣接要素を交換する
// 一度でも交換した場合は1、交換できなかった場合は0を返す

int	spin_bubble_pass(t_program *program, int minimum, int maximum)
{
	size_t	i;
	int		swapped;

	i = 0;
	swapped = 0;
	while (i < program->size_a && !stack_a_is_sorted(program))
	{
		if (!(program->stack_a->value == maximum
					&& program->stack_a->next->value == minimum)
		&& program->stack_a->value > program->stack_a->next->value)
		{
			op_sa(program);
			swapped = 1;
		}
		if (!stack_a_is_sorted(program))
			op_ra(program);
		i++;
	}
	return (swapped);
}
