/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   7-1-1_find_limits.c                               :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:26 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:27 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// スタックAを一周し、最小値と最大値を見つける

void	find_limits(t_program *program, int *minimum, int *maximum)
{
	t_node	*node;

	node = program->stack_a;
	*minimum = node->value;
	*maximum = node->value;
	while (node != NULL)
	{
		if (node->value < *minimum)
			*minimum = node->value;
		if (node->value > *maximum)
			*maximum = node->value;
		node = node->next;
	}
}
