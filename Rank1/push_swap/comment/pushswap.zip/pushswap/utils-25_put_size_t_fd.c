/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   utils-25_put_size_t_fd.c                          :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:48:49 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:50:28 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// size_t型の整数を10進数として指定先へ出力する

void	put_size_t_fd(size_t number, int fd)
{
	if (number >= 10)
		put_size_t_fd(number / 10, fd);
	ft_putchar_fd((char)('0' + number % 10), fd);
}
