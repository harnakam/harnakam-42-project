/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   6_stack_a_is_sorted.c                             :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/22 22:17:46 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:23 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// スタックAの全要素が先頭から昇順に並んでいるか確認する

int	stack_a_is_sorted(const t_program *program)
{
	t_node	*current;

	// 隣り合う数値が昇順になっているか確認する
	current = program->stack_a;
	while (current != NULL && current->next != NULL)
	{
		if (current->value > current->next->value)
			return (0);
		current = current->next;
	}
	return (1);
}
