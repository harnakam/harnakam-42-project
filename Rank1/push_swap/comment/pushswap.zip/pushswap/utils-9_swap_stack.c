/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   utils-9_swap_stack.c                              :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:48:36 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:50:19 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// スタック先頭にある二つのノードの値と順位を交換する

void	swap_stack(t_node *stack)
{
	int	value;
	int	index;

	if (stack == NULL || stack->next == NULL)
		return ;
	value = stack->value;
	index = stack->index;
	stack->value = stack->next->value;
	stack->index = stack->next->index;
	stack->next->value = value;
	stack->next->index = index;
}
