/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   7-4-2_restore_stack_a.c                           :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:54 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:54 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// Bの最大要素を先頭へ合わせ、すべての要素をAへ戻す

void	restore_stack_a(t_program *program)
{
	size_t	position;
	size_t	steps;

	position = find_maximum_position(program->stack_b);
	if (position <= program->size_b / 2)
		while (position-- > 0)
		op_rb(program);
	else
	{
		steps = program->size_b - position;
		while (steps-- > 0)
			op_rrb(program);
	}
	while (program->size_b > 0)
		op_pa(program);
}
