/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   utils-2_strings_are_equal.c                       :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:29:09 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:50:11 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 二つの文字列を先頭から比較する
// すべて同じ場合は1、一文字でも異なる場合は0を返す

int	strings_are_equal(const char *first, const char *second)
{
	return (ft_strncmp(first, second, ft_strlen(second) + 1) == 0);
}
