#include "push_swap.h"

// 一つの要素について四つの回転方向を比較し、最小の移動を返す
t_move	choose_node_move(t_program *program, t_node *node,
	size_t a_position, t_move best)
{
	t_move	candidate;
	size_t	b_position;
	int		mode;

	b_position = insertion_position(program, node->index);
	mode = 0;
	while (mode < 4)
	{
		candidate = make_move(program, a_position, b_position, mode++);
		if (candidate.cost < best.cost)
			best = candidate;
	}
	return (best);
}
