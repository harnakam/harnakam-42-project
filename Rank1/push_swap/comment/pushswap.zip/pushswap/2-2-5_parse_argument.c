/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   2-2-5_parse_argument.c                            :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:17 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:17 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 一つの引数を空白で分割し、含まれるすべての整数を読み取る

int	parse_argument(t_program *program, const char *argument)
{
	size_t	i;
	size_t	start;
	int		found_number;

	i = 0;
	found_number = 0;
	while (argument[i] != '\0')
	{
		while (is_space(argument[i]))
			i++;
		if (argument[i] == '\0')
			break ;
		start = i;
		while (argument[i] != '\0' && !is_space(argument[i]))
			i++;
		if (parse_one_word(program, argument + start, i - start) == ERROR)
			return (ERROR);
		found_number = 1;
	}
	if (!found_number)
		return (ERROR);
	return (SUCCESS);
}
