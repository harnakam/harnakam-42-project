/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   utils-7-1_merge_values.c                          :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:48:34 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 18:31:14 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 二つの整列済み範囲を小さい値から一つの範囲へ統合する
void merge_values(int * values, int * temporary, size_t left,
	size_t	middle, size_t right)
{
	size_t	i;
	size_t	j;
	size_t	position;

	i = left;
	j = middle;
	position = left;
	while (i < middle && j < right)
	{
		if (values[i] < values[j])
			temporary[position++] = values[i++];
		else
			temporary[position++] = values[j++];
	}
	while (i < middle)
		temporary[position++] = values[i++];
	while (j < right)
		temporary[position++] = values[j++];
	copy_merged_values(values, temporary, left, right);
}
