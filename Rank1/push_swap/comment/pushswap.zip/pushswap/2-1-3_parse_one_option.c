#include "push_swap.h"

// 一つのオプションを読み取り、プログラム設定へ保存する
int	parse_one_option(t_program *program, const char *argument)
{
	t_strategy	strategy;

	if (strings_are_equal(argument, "--bench"))
		return (program->bench_enabled = 1, SUCCESS);
	if (!is_strategy_option(argument))
		return (ERROR);
	strategy = get_strategy_from_option(argument);
	if (program->requested_strategy != STRATEGY_NONE
		&& program->requested_strategy != strategy)
		return (ERROR);
	program->requested_strategy = strategy;
	return (SUCCESS);
}
