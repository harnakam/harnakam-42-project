/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   2_process_input.c                                 :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:09 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:09 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// オプションと数値を順番に読み取り、入力全体を処理する
// どちらかに問題がある場合は1、すべて正しい場合は0を返す

int	process_input(t_program *program)
{
	// 2-1. オプションを読み取る
	if (parse_options(program) == ERROR)
		return (ERROR);
	// 2-2. 数値を読み取り、スタックAを作る
	if (parse_numbers_into_stack_a(program) == ERROR)
		return (ERROR);
	return (SUCCESS);
}
