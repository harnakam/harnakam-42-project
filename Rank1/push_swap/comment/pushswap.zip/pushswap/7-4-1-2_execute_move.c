/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   7-4-1-2_execute_move.c                            :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:51 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:51 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 選択された回転を実行し、対象の要素をスタックBへ移動する

void	execute_move(t_program *program, t_move move)
{
	execute_shared_rotations(program, &move);
	while (move.a_steps-- > 0)
	{
		if (move.a_reverse)
			op_rra(program);
		else
			op_ra(program);
	}
	while (move.b_steps-- > 0)
	{
		if (move.b_reverse)
			op_rrb(program);
		else
			op_rb(program);
	}
	op_pb(program);
}
