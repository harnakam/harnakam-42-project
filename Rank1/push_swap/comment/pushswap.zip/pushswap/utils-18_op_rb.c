/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   utils-18_op_rb.c                                  :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:48:55 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:48:56 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// スタックBを上方向へ一つ回転し、rbを出力する

void	op_rb(t_program *program)
{
	if (program->size_b < 2)
		return ;
	rotate_stack(&program->stack_b);
	print_operation(program, "rb", &program->operations.rb);
}
