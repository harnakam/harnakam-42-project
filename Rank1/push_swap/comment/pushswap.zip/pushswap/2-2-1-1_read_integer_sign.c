#include "push_swap.h"

// 文字列先頭の符号を読み取り、数字が始まる位置を更新する
int	read_integer_sign(const char *string, size_t *position)
{
	int	sign;

	sign = 1;
	if (string[*position] == '+' || string[*position] == '-')
	{
		if (string[*position] == '-')
			sign = -1;
		(*position)++;
	}
	return (sign);
}
