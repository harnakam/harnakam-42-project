/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   2-1-2_get_strategy_from_option.c                  :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:11 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:11 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// オプション文字列を対応するソート方法へ変換する

t_strategy	get_strategy_from_option(const char *argument)
{
	if (strings_are_equal(argument, "--simple"))
		return (STRATEGY_SIMPLE);
	if (strings_are_equal(argument, "--medium"))
		return (STRATEGY_MEDIUM);
	if (strings_are_equal(argument, "--complex"))
		return (STRATEGY_COMPLEX);
	if (strings_are_equal(argument, "--adaptive"))
		return (STRATEGY_ADAPTIVE);
	if (strings_are_equal(argument, "--ultra"))
		return (STRATEGY_ULTRA);
	return (STRATEGY_NONE);
}
