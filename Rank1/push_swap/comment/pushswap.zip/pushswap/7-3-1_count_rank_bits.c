/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   7-3-1_count_rank_bits.c                           :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:39 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:39 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 0から要素数未満の順位を表現するために必要なbit数を求める

size_t	count_rank_bits(size_t size)
{
	size_t	bits;

	bits = 0;
	while (((size - 1) >> bits) != 0)
		bits++;
	return (bits);
}
