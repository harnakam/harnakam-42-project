/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   utils-22_op_rrr.c                                 :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:39:49 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:48:51 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// スタックAとBを同時に下方向へ回転し、rrrを出力する

void	op_rrr(t_program *program)
{
	if (program->size_a < 2 || program->size_b < 2)
		return ;
	reverse_rotate_stack(&program->stack_a);
	reverse_rotate_stack(&program->stack_b);
	print_operation(program, "rrr", &program->operations.rrr);
}
