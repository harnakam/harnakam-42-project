#include "push_swap.h"

// 整列済み配列から各ノードの値に対応する順位を保存する
void	assign_node_ranks(t_node *stack, const int *values, size_t size)
{
	while (stack != NULL)
	{
		stack->index = find_rank(values, size, stack->value);
		stack = stack->next;
	}
}
