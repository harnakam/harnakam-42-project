/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   utils-21_op_rrb.c                                 :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:39:54 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:48:54 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// スタックBを下方向へ一つ回転し、rrbを出力する

void	op_rrb(t_program *program)
{
	if (program->size_b < 2)
		return ;
	reverse_rotate_stack(&program->stack_b);
	print_operation(program, "rrb", &program->operations.rrb);
}
