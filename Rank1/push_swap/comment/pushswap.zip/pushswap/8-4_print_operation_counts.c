/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   8-4_print_operation_counts.c                      :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:50:00 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:50:00 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 全体の操作回数と命令ごとの操作回数を表示する

void	print_operation_counts(const t_operation_count *operations)
{
	print_size_line("Total operations: ", operations->total);
	print_size_line("sa:  ", operations->sa);
	print_size_line("sb:  ", operations->sb);
	print_size_line("ss:  ", operations->ss);
	print_size_line("pa:  ", operations->pa);
	print_size_line("pb:  ", operations->pb);
	print_size_line("ra:  ", operations->ra);
	print_size_line("rb:  ", operations->rb);
	print_size_line("rr:  ", operations->rr);
	print_size_line("rra: ", operations->rra);
	print_size_line("rrb: ", operations->rrb);
	print_size_line("rrr: ", operations->rrr);
}
