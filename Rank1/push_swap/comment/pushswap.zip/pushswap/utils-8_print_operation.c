/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   utils-8_print_operation.c                         :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:37:17 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:50:20 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 実行した命令を出力し、命令別と全体の操作回数を増やす

void	print_operation(t_program *program, const char *name, size_t *counter)
{
	ft_printf("%s\n", name);
	(*counter)++;
	program->operations.total++;
}
