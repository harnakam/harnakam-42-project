/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   7-2-4_restore_runs_to_stack_a.c                   :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:36 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:36 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// スタックBの最大要素を順番にスタックAへ戻す

void	restore_runs_to_stack_a(t_program *program)
{
	while (program->size_b > 0)
	{
		move_maximum_to_top(program);
		op_pa(program);
	}
}
