/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   2-1-1_is_strategy_option.c                        :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:10 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:10 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 引数が使用可能なソート方法のオプションか確認する

int	is_strategy_option(const char *argument)
{
	if (strings_are_equal(argument, "--simple"))
		return (1);
	if (strings_are_equal(argument, "--medium"))
		return (1);
	if (strings_are_equal(argument, "--complex"))
		return (1);
	if (strings_are_equal(argument, "--adaptive"))
		return (1);
	if (strings_are_equal(argument, "--ultra"))
		return (1);
	return (0);
}
