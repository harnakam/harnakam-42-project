/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   1_initialize_program.c                            :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/22 22:14:38 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 18:26:06 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 引数とスタックを管理するプログラム構造体を初期状態にする
// mainから受け取ったargcとargvも同じ構造体へ保存する

void	initialize_program(t_program *program, int argc, char **argv)
{
	// mainから受け取った引数を保存する
	program->argc = argc;
	program->argv = argv;
	// 二つのスタックを空の状態にする
	program->stack_a = NULL;
	program->stack_b = NULL;
	program->size_a = 0;
	program->size_b = 0;
	// ソート方法をまだ指定されていない状態にする
	program->requested_strategy = STRATEGY_NONE;
	program->selected_strategy = STRATEGY_NONE;
	// ベンチマークを無効な状態にする
	program->bench_enabled = 0;
	// 最初の乱れ具合を0にする
	program->initial_disorder = 0.0;
	// 全操作回数を0にする
	initialize_operation_count(&program->operations);
}
