/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   utils-7-3_find_rank.c                             :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:33:25 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:50:17 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 自分より小さな数を数え、指定された値の順位を返す

int	find_rank(const int *values, size_t size, int value)
{
	size_t	i;
	int		rank;

	i = 0;
	rank = 0;
	while (i < size)
	{
		if (values[i] < value)
			rank++;
		i++;
	}
	return (rank);
}
// 整列済み配列を二分探索し、指定された値の順位を返す

// int	find_rank(const int *values, size_t size, int value)
// {
// 	size_t	left;
// 	size_t	right;
// 	size_t	middle;

// 	left = 0;
// 	right = size;
// 	while (left < right)
// 	{
// 		middle = left + (right - left) / 2;
// 		if (values[middle] < value)
// 			left = middle + 1;
// 		else
// 			right = middle;
// 	}
// 	return ((int) left);
// }
