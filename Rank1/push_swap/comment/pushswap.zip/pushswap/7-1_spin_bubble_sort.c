/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   7-1_spin_bubble_sort.c                            :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/22 22:24:30 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:25 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// swapとrotateで隣接要素を繰り返し比較して昇順に並べる

void	spin_bubble_sort(t_program *program)
{
	int	minimum;
	int	maximum;

	// 7-1-1. 比較で使用する最小値と最大値を調べる
	find_limits(program, &minimum, &maximum);
	// 7-1-2. 整列が完了するまでスタックAを一周ずつ比較する
	while (!stack_a_is_sorted(program))
		if (!spin_bubble_pass(program, minimum, maximum))
		return ;
}
