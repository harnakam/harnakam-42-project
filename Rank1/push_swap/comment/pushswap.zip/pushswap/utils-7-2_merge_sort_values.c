/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   utils-7-2_merge_sort_values.c                     :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:48:35 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:50:16 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 配列を半分ずつに分割し、マージソートで昇順に並べる
void merge_sort_values(int * values, int * temporary, size_t left,
	size_t	right)
{
	size_t	middle;

	if (right - left < 2)
		return ;
	middle = left + (right - left) / 2;
	merge_sort_values(values, temporary, left, middle);
	merge_sort_values(values, temporary, middle, right);
	merge_values(values, temporary, left, middle, right);
}
