/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   5_select_strategy.c                               :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/22 22:17:26 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:21 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 明示された方法、または自動選択した方法を実行用として保存する

void	select_strategy(t_program *program)
{
	// adaptive以外が指定されていれば、その方法を使用する
	if (program->requested_strategy != STRATEGY_ADAPTIVE)
	{
		program->selected_strategy = program->requested_strategy;
		return ;
	}
	// adaptiveなら要素数と乱れ具合から自動選択する
	program->selected_strategy = select_adaptive_strategy(program);
}
