/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   7-3-2_radix_pass.c                                :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:40 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:40 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 指定bitが0の要素をBへ移し、1の要素をAの末尾へ送る

void	radix_pass(t_program *program, size_t bit)
{
	size_t	i;
	size_t	size;

	i = 0;
	size = program->size_a;
	while (i++ < size)
	{
		if (((program->stack_a->index >> bit) & 1) == 0)
			op_pb(program);
		else
			op_ra(program);
	}
	while (program->size_b > 0)
		op_pa(program);
}
