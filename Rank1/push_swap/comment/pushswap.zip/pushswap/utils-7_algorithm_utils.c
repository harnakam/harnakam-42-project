/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   utils-7_algorithm_utils.c                         :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:48:32 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:50:17 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// スタックAの各ノードへ0から始まる値の順位を保存する

int	assign_rank_indexes(t_program *program)
{
	int		*values;
	int		*temporary;
	// utils-7-1. 順位計算に使用する二つの配列を確保する
	values = malloc(program->size_a * sizeof(*values));
	temporary = malloc(program->size_a * sizeof(*temporary));
	if (values == NULL || temporary == NULL)
		return (free(values), free(temporary), ERROR);
	// utils-7-2. スタックAの値を配列へコピーして整列する
	copy_stack_values(program->stack_a, values);
	merge_sort_values(values, temporary, 0, program->size_a);
	// utils-7-3. 整列済み配列から各ノードへ順位を保存する
	assign_node_ranks(program->stack_a, values, program->size_a);
	free(values);
	free(temporary);
	return (SUCCESS);
}
