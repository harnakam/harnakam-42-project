/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   utils-6_free_all.c                                :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/22 22:19:16 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:50:14 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// スタックAとBに残っているすべてのノードを解放する

void	free_all(t_program *program)
{
	// スタックaの全ノードを解放する
	free_stack(&program->stack_a);
	// スタックbの全ノードを解放する
	free_stack(&program->stack_b);
	// 要素数も空の状態へ戻す
	program->size_a = 0;
	program->size_b = 0;
}
