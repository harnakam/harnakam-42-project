/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   4-1_count_inversions.c                            :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:20 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:20 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 後ろの要素より大きい要素の組み合わせを数える
// この組み合わせの数を反転数として返す

size_t	count_inversions(const t_node *stack)
{
	const t_node	*first;
	const t_node	*second;
	size_t			inversions;

	inversions = 0;
	first = stack;
	while (first != NULL)
	{
		second = first->next;
		while (second != NULL)
		{
			if (first->value > second->value)
				inversions++;
			second = second->next;
		}
		first = first->next;
	}
	return (inversions);
}
