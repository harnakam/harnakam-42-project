/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   7-2-2_move_runs_to_stack_b.c                      :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:34 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:34 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 順位が指定幅に入る要素を順番にスタックBへまとめる

void	move_runs_to_stack_b(t_program *program, size_t width)
{
	size_t	accepted;

	accepted = 0;
	while (program->size_a > 0)
	{
		if ((size_t) program->stack_a->index <= accepted)
		{
			op_pb(program);
			op_rb(program);
			accepted++;
		}
		else if ((size_t) program->stack_a->index <= accepted + width)
		{
			op_pb(program);
			accepted++;
		}
		else
			op_ra(program);
	}
}
