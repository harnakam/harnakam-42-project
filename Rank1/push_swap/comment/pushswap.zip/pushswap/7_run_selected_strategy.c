/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   7_run_selected_strategy.c                         :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/22 22:17:59 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:24 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 選択済みのソート方法に対応するアルゴリズムを実行する

void	run_selected_strategy(t_program *program)
{
	// simpleならSpin Bubble Sortを使用する
	if (program->selected_strategy == STRATEGY_SIMPLE)
		spin_bubble_sort(program);
	// mediumならSpin Run Insertionを使用する
	else if (program->selected_strategy == STRATEGY_MEDIUM)
		spin_run_insertion(program);
	// complexならRadix Sortを使用する
	else if (program->selected_strategy == STRATEGY_COMPLEX)
		radix_sort(program);
	// ultraならOptiCSRIを使用する
	else if (program->selected_strategy == STRATEGY_ULTRA)
		opticsri_sort(program);
}
