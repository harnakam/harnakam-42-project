/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   2-2-3_append_value_to_stack_a.c                   :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:15 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:16 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 新しいノードを作り、指定された整数をスタックAの末尾へ追加する

int	append_value_to_stack_a(t_program *program, int value)
{
	t_node	*new_node;
	t_node	*last;

	new_node = malloc(sizeof(t_node));
	if (new_node == NULL)
		return (ERROR);
	new_node->value = value;
	new_node->index = -1;
	new_node->prev = NULL;
	new_node->next = NULL;
	if (program->stack_a == NULL)
		program->stack_a = new_node;
	else
	{
		last = program->stack_a;
		while (last->next != NULL)
			last = last->next;
		last->next = new_node;
		new_node->prev = last;
	}
	program->size_a++;
	return (SUCCESS);
}
