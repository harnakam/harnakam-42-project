/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   utils-15_op_pa.c                                  :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:48:57 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:48:57 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// スタックBの先頭要素をスタックAへ移動し、paを出力する

void	op_pa(t_program *program)
{
	if (program->size_b == 0)
		return ;
	push_stack(&program->stack_b, &program->stack_a,
		&program->size_b, &program->size_a);
	print_operation(program, "pa", &program->operations.pa);
}
