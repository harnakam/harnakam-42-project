/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   8-3_print_disorder.c                              :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:58 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:58 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 0から1の乱れ具合を百分率へ変換して表示する

void	print_disorder(double disorder)
{
	int	percentage;
	int	decimal;

	percentage = (int)(disorder * 100.0);
	decimal = (int)(disorder * 10000.0) % 100;
	ft_putstr_fd("Initial disorder: ", 2);
	ft_putnbr_fd(percentage, 2);
	ft_putchar_fd('.', 2);
	if (decimal < 10)
		ft_putchar_fd('0', 2);
	ft_putnbr_fd(decimal, 2);
	ft_putendl_fd("%", 2);
}
