/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   utils-5_free_and_exit_success.c                   :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/22 22:21:11 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:50:13 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 確保済みのメモリをすべて解放する
// 正常終了を表す0を返す

int	free_all_and_exit_success(t_program *program)
{
	// 正常終了前に確保済みのメモリをすべて解放する
	free_all(program);
	return (SUCCESS);
}
