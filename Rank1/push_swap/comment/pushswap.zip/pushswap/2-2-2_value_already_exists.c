/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   2-2-2_value_already_exists.c                      :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:14 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:14 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 指定された整数が既にスタックAに存在するか確認する

int	value_already_exists(const t_program *program, int value)
{
	t_node	*current;

	current = program->stack_a;
	while (current != NULL)
	{
		if (current->value == value)
			return (1);
		current = current->next;
	}
	return (0);
}
