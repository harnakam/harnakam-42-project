/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   push_swap.c                                       :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/17 10:08:19 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 18:19:55 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int	main(int argc, char **argv)
{
	t_program	program;

	if (argc == 1)
		return (0);
	initialize_program(&program, argc, argv);
	if (process_input(&program) == ERROR)
		return (print_error_and_free(&program));
	if (stack_a_is_empty(&program))
		return (free_all_and_exit_success(&program));
	compute_and_save_initial_disorder(&program);
	select_strategy(&program);
	if (stack_a_is_sorted(&program))
	{
		print_benchmark_if_enabled(&program);
		free_all(&program);
		return (0);
	}
	run_selected_strategy(&program);
	print_benchmark_if_enabled(&program);
	free_all(&program);
	return (0);
}
