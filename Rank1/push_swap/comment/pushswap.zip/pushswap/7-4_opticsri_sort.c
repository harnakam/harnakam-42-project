/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   7-4_opticsri_sort.c                               :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:41 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:41 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 各要素の挿入コストを比較し、操作数を抑えながら昇順に並べる

void	opticsri_sort(t_program *program)
{
	// 7-4-1. 各要素へ値の順位を割り当てる
	if (assign_rank_indexes(program) == ERROR)
		return ;
	// 7-4-2. 操作数が最小になる要素からBへ移動する
	move_all_optimally_to_stack_b(program);
	// 7-4-3. 降順の循環列を最大値からAへ戻す
	restore_stack_a(program);
}
