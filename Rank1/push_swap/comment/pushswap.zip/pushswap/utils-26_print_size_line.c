/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   utils-26_print_size_line.c                        :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:48:47 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:50:26 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// ラベルとsize_t型の整数を標準エラーへ一行で表示する

void	print_size_line(const char *label, size_t number)
{
	ft_putstr_fd((char *) label, 2);
	put_size_t_fd(number, 2);
	ft_putchar_fd('\n', 2);
}
