/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   8-1_get_strategy_name.c                           :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:56 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:56 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// ソート方法をベンチマーク表示用の名前へ変換する

const char	*get_strategy_name(t_strategy strategy)
{
	if (strategy == STRATEGY_SIMPLE)
		return ("Spin Bubble Sort");
	if (strategy == STRATEGY_MEDIUM)
		return ("Spin Run Insertion");
	if (strategy == STRATEGY_COMPLEX)
		return ("Radix Sort");
	if (strategy == STRATEGY_ULTRA)
		return ("OptiCSRI");
	return ("Unknown");
}
