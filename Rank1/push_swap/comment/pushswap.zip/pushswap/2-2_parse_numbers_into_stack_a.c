/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   2-2_parse_numbers_into_stack_a.c                  :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/22 22:15:40 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:12 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// オプション以外の全引数を読み取り、スタックAを作成する

int	parse_numbers_into_stack_a(t_program *program)
{
	int	i;

	// オプション以外の引数を数値として読み取る
	i = 1;
	while (i < program->argc)
	{
		if (!is_option(program->argv[i]))
		{
			if (parse_argument(program, program->argv[i]) == ERROR)
				return (ERROR);
		}
		i++;
	}
	return (SUCCESS);
}
