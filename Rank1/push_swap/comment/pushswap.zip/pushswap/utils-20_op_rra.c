/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   utils-20_op_rra.c                                 :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:39:56 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:39:56 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// スタックAを下方向へ一つ回転し、rraを出力する

void	op_rra(t_program *program)
{
	if (program->size_a < 2)
		return ;
	reverse_rotate_stack(&program->stack_a);
	print_operation(program, "rra", &program->operations.rra);
}
