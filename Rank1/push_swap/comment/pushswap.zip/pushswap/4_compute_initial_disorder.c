/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   4_compute_initial_disorder.c                      :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/22 22:17:04 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:19 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 反転数を全組み合わせ数で割り、最初の乱れ具合として保存する

void	compute_and_save_initial_disorder(t_program *program)
{
	size_t	total_pairs;
	size_t	inversions;

	// 要素が一つ以下なら乱れは存在しない
	if (program->size_a <= 1)
	{
		program->initial_disorder = 0.0;
		return ;
	}
	// 全ての数値の組み合わせ数を求める
	total_pairs = program->size_a * (program->size_a - 1) / 2;
	// 順番が逆になっている組み合わせ数を求める
	inversions = count_inversions(program->stack_a);
	// 乱れている組み合わせの割合を保存する
	program->initial_disorder = (double) inversions / (double) total_pairs;
}
