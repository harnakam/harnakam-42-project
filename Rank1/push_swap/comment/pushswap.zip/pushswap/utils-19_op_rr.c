#include "push_swap.h"

// スタックAとBを同時に上方向へ回転し、rrを出力する
void	op_rr(t_program *program)
{
	if (program->size_a < 2 || program->size_b < 2)
		return ;
	rotate_stack(&program->stack_a);
	rotate_stack(&program->stack_b);
	print_operation(program, "rr", &program->operations.rr);
}
