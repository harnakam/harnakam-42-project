#include "push_swap.h"

// 数字をlong型へ変換し、int型の範囲を超えないか確認する
int	read_integer_digits(const char *string, size_t length,
	size_t position, int sign, long *number)
{
	*number = 0;
	while (position < length)
	{
		if (!ft_isdigit((unsigned char)string[position]))
			return (ERROR);
		*number = *number * 10 + (string[position] - '0');
		if (sign == 1 && *number > INT_MAX)
			return (ERROR);
		if (sign == -1 && *number > -(long)INT_MIN)
			return (ERROR);
		position++;
	}
	return (SUCCESS);
}
