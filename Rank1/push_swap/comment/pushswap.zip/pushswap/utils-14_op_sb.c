/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   utils-14_op_sb.c                                  :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:48:59 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:48:59 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// スタックBの先頭二要素を交換し、sbを出力する

void	op_sb(t_program *program)
{
	if (program->size_b < 2)
		return ;
	swap_stack(program->stack_b);
	print_operation(program, "sb", &program->operations.sb);
}
