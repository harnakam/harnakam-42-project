#include "push_swap.h"

// スタックAの先頭要素をスタックBへ移動し、pbを出力する
void	op_pb(t_program *program)
{
	if (program->size_a == 0)
		return ;
	push_stack(&program->stack_a, &program->stack_b,
		&program->size_a, &program->size_b);
	print_operation(program, "pb", &program->operations.pb);
}
