/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   7-2-3_move_maximum_to_top.c                       :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:35 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:35 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// より少ない回転方向を使ってスタックBの最大要素を先頭へ移動する

void	move_maximum_to_top(t_program *program)
{
	size_t	position;
	size_t	steps;

	position = find_maximum_position(program->stack_b);
	if (position <= program->size_b / 2)
		while (position-- > 0)
		op_rb(program);
	else
	{
		steps = program->size_b - position;
		while (steps-- > 0)
			op_rrb(program);
	}
}
