/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   utils-4_print_error_and_free.c                    :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/22 22:20:48 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 18:21:09 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 確保済みのメモリを解放してから標準エラー出力へErrorを表示する
// エラー終了を表す1を返す

int	print_error_and_free(t_program *program)
{
	// エラー時も確保済みのメモリをすべて解放する
	free_all(program);
	// エラーメッセージは標準エラー出力へ表示する
	ft_putendl_fd("Error", 2);
	return (ERROR);
}
