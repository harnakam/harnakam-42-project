/* ************************************************************************** */
/*                                                                            */
/*                                                       :::      ::::::::    */
/*   7-2-1_chunk_width.c                               :+:      :+:    :+:    */
/*                                                   +:+ +:+         +:+      */
/*   By: harnakam <harnakam@student.42tokyo.jp>    #+#  +:+       +#+         */
/*                                               +#+#+#+#+#+   +#+            */
/*   Created: 2026/07/23 17:49:33 by harnakam         #+#    #+#              */
/*   Updated: 2026/07/23 17:49:33 by harnakam        ###   ########.fr        */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// 要素数の平方根以上になる最小の整数をrun幅として求める

size_t	chunk_width(size_t size)
{
	size_t	width;

	width = 1;
	while (width * width < size)
		width++;
	return (width);
}
